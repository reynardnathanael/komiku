export class ComicModel {
    constructor(public comic_id: number, public title: string, public cover: string, public view: number) {

    }
}